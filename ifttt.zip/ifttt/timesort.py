#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 09:37:19 2018

@author: helio
"""
import json, operator

with open('test.json') as f:
    data = json.load(f)

data.sort(key=operator.itemgetter('_id'))
print(json.dumps(data, indent=2))